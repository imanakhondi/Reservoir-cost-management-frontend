const PAGES = {
  Error404: "error404Page",
  Login: "loginAdminPage",
  Dashboard: "dashboardPage",
  Users: "usersPage",
  AddUser: "addUserPage",
  AddUsersGroup: "addUsersGroupPage",
};

export default PAGES;
