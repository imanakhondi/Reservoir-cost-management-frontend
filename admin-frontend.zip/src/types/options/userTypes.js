import utils from "../../utils";
import { USER_TYPES } from "../";

const { userTypes: strings } = utils.getLSLocale();

const userTypes = [
  { value: USER_TYPES.operator, text: strings.operator },
  { value: USER_TYPES.administrator, text: strings.administrator },
];

export default userTypes;
