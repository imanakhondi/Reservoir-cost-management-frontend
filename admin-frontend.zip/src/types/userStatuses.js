export const USER_STATUSES = {
  active: "active",
  deactive: "deactive",
};
