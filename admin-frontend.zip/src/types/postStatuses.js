export const POST_STATUSES = {
  PUBLISHED: "published",
  WAITING: "waiting",
  HIDDEN: "hidden",
  DELETED: "deleted",
};
