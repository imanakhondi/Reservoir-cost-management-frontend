export const PAGE_ITEMS = {
  ITEMS_10: 10,
  ITEMS_20: 20,
  ITEMS_50: 50,
};
