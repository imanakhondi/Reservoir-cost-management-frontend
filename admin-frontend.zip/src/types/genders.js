export const GENDERS = {
  male: "male",
  female: "female",
};
