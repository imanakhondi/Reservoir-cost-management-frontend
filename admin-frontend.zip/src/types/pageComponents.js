import { Error404 } from "../features/error/components";
import { Login } from "../features/auth/components";
import { Dashboard } from "../features/dashboard/components";
import { Users } from "../features/users/components";
import { AddUser } from "../features/users/components";
import { AddUsersGroup } from "../features/users/components";

export { Error404, Login, Dashboard, Users, AddUser, AddUsersGroup };
