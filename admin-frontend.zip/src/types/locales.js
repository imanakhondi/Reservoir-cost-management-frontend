export const LOCALES = {
  FA: "fa",
};
