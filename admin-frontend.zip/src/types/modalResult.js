export const MODAL_RESULT = {
    OK: "ok",
    CANCEL: "cancel",
    YES: "yes",
    NO: "no",
    CLOSE: "close",
};
