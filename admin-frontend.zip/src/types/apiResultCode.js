export const API_RESULT_CODES = {
  OK: "1",
  ERROR: "0",
};
