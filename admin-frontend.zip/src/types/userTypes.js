export const USER_TYPES = {
  operator: "operator",
  administrator: "administrator",
};
