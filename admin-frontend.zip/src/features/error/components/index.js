import ErrorBoundary from "./ErrorBoundry";
import FallbackError from "./FallbackError";
import Error404 from "./Error404";

export { ErrorBoundary, FallbackError, Error404 };
