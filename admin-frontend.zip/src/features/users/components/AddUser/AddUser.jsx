import React from "react";

import {
  ModalAddUserPrompt,
  AuthLayout,
  InputCheckbox,
  InputSelect,
  InputText,
  ButtonPrimary,
} from "../../../../components";
import { useAddUserPageService } from "../../hooks";
import Svg, { SvgPath } from "../../../../components/svg";
import { Link } from "react-router-dom";
import utils from "../../../../utils";
import { USER_PERMISSIONS, USER_TYPES } from "../../../../types";
import userTypes from "../../../../types/options/userTypes";

const AddUser = () => {
  const service = useAddUserPageService();
  const { permissions } = utils.getLSLocale();

  return (
    <AuthLayout>
      <ModalAddUserPrompt onAddNextUser={service.onAddNextUser} />
      <div className="p-3">
        <div className="flex flex-row justify-start items-center gap-2 h-12 mb-2">
          <Link to={`/users`}>
            <Svg
              SvgPath={<SvgPath.SvgChevronDown />}
              width="24"
              height="24"
              className="icon -rotate-90 hover:fill-primary"
            />
          </Link>
          <h1 className="font-bold">{service.strings._title}</h1>
        </div>
        <div className="bg-white rounded section-body p-4">
          <h2 className="text-primary font-bold">{service.strings.header1}</h2>
          <div className="grid grid-cols-3 gap-4">
            <InputText field="mobile" required />
            <InputText field="nameFamily" required />
            <InputText field="username" required />
          </div>
          <h2 className="text-primary font-bold mt-2 mb-4">
            {service.strings.header2}
          </h2>
          <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 border border-border-line rounded p-4 relative">
            <div className="absolute bottom-0 left-0">
              <InputCheckbox
                name="selectAll"
                field="selectAll"
                containerClassName="mx-4 mb-3 py-2 px-3 rounded bg-bg"
                onChange={(e) => service.onSelectAll(e)}
              />
            </div>
            <div>
              <span className="text-xs font-bold">
                {service.strings.postPermissions}
              </span>
              <div className="flex flex-col gap-3 mt-3">
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="postSend"
                  value={USER_PERMISSIONS.postSend}
                />
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="postSendAnonymous"
                  value={USER_PERMISSIONS.postSendAnonymous}
                />
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="postAttachImage"
                  value={USER_PERMISSIONS.postAttachImage}
                />
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="postAttachFile"
                  value={USER_PERMISSIONS.postAttachFile}
                />
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="postQuote"
                  value={USER_PERMISSIONS.postQuote}
                />
              </div>
            </div>
            <div>
              <span className="text-xs font-bold">
                {service.strings.commentPermissions}
              </span>
              <div className="flex flex-col gap-3 mt-3">
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="commentSend"
                  value={USER_PERMISSIONS.commentSend}
                />
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="commentSendAnonymous"
                  value={USER_PERMISSIONS.commentSendAnonymous}
                />
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="commentAttachImage"
                  value={USER_PERMISSIONS.commentAttachImage}
                />
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="commentAttachFile"
                  value={USER_PERMISSIONS.commentAttachFile}
                />
              </div>
            </div>
            <div>
              <span className="text-xs font-bold">
                {service.strings.chatPermissions}
              </span>
              <div className="flex flex-col gap-3 mt-3">
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="chatUse"
                  value={USER_PERMISSIONS.chatUse}
                />
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="chatUsePrivate"
                  value={USER_PERMISSIONS.chatUsePrivate}
                />
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="chatCreateGroup"
                  value={USER_PERMISSIONS.chatCreateGroup}
                />
              </div>
            </div>
            <div>
              <span className="text-xs font-bold">
                {service.strings.otherPermissions}
              </span>
              <div className="flex flex-col gap-3 mt-3">
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="pollCreate"
                  value={USER_PERMISSIONS.pollCreate}
                />
                <InputCheckbox
                  strings={permissions}
                  name="permissions"
                  field="kudosSend"
                  value={USER_PERMISSIONS.kudosSend}
                />
              </div>
            </div>
          </div>
          <h2 className="text-primary font-bold mt-6">
            {service.strings.header3}
          </h2>
          <div className="grid grid-cols-3 gap-4">
            <InputText field="email" />
            <InputSelect
              field="type"
              options={userTypes}
              defaultValue={USER_TYPES.operator}
            />
            <div></div>
          </div>
        </div>
        <div className="flex flex-row justify-end mt-4">
          <ButtonPrimary
            label="btnAdd"
            onClick={service.handleSubmit(service.onSubmit)}
          />
        </div>
      </div>
    </AuthLayout>
  );
};

export default AddUser;
