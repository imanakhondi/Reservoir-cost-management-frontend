import React from "react";

import {
  AuthLayout,
  InputFile,
  ModalAddUsersGroupPrompt,
} from "../../../../components";
import { useAddUsersGroupPageService } from "../../hooks";
import Svg, { SvgPath } from "../../../../components/svg";
import { Link } from "react-router-dom";
import { UPLOAD_STATUS } from "../../../../types";

const AddUsersGroup = () => {
  const service = useAddUsersGroupPageService();

  const renderNotUploaded = () => (
    <div className="w-full bg-primary-lighter rounded border border-dashed border-primary">
      <label
        className="w-full py-5 px-6 flex flex-row justify-between items-center cursor-pointer drop-area"
        htmlFor="csvFile"
        title={service.strings.header}
        id="dropArea"
        onDragOver={service.onDragOver}
        onDrop={service.onDrop}
        onDragEnter={service.onDragEnter}
        onDragLeave={service.onDragLeave}
      >
        <div className="flex flex-row items-center gap-3">
          <Svg
            SvgPath={<SvgPath.SvgUpload pathClassName={"stroke-primary"} />}
            width="64"
            height="64"
            className="icon-complex"
            viewBox={"0 0 64 64"}
          />
          <div className="flex flex-col">
            <p className="text-primary text-lg font-bold mb-2">
              {service.strings.notUploadedHeader}
            </p>
            <p className="text-subline text-xs">
              {service.strings.notUploadedHeaderText}
            </p>
          </div>
        </div>
        <div>
          <span className="bg-primary-light text-primary py-2 px-3 rounded text-base font-bold">
            {service.strings.uploadBtn}
          </span>
          <InputFile
            field="csvFile"
            accept=".csv,.xls,.xlsx"
            file={service.csvFile}
            showFile={true}
            onChangeFile={(e) => service.onChangeCsvFile(e)}
            inputStyle={{ display: "none" }}
          />
        </div>
      </label>
    </div>
  );

  const renderUploading = () => (
    <div className="w-full bg-white rounded border border-border-line py-5 px-6 flex flex-row justify-start items-center gap-3">
      <Svg
        SvgPath={<SvgPath.SvgDocument pathClassName={"stroke-primary"} />}
        width="64"
        height="64"
        className="icon-complex"
        viewBox={"0 0 48 48"}
      />
      <div className="flex flex-col">
        <p className="text-subline text-lg font-bold mb-2">
          {service.csvFile?.name}
        </p>
        <p className="text-subline text-xs">
          {service.strings.uploadingHeaderText}
        </p>
      </div>
    </div>
  );

  const renderUploaded = () => (
    <div className="w-full bg-primary-lighter rounded border border-border-line py-5 px-6 flex flex-row justify-start items-center gap-3">
      <Svg
        SvgPath={<SvgPath.SvgDocument pathClassName={"stroke-primary"} />}
        width="64"
        height="64"
        className="icon-complex"
        viewBox={"0 0 48 48"}
      />
      <div className="flex flex-col">
        <p className="text-subline text-lg font-bold mb-2">
          {service.csvFile?.name}
        </p>
        <p className="text-subline text-xs flex flex-row gap-1">
          <span>{service.strings.uploadedHeaderText}</span>
          <span
            className={`font-medium ${
              service.uploadStatus === UPLOAD_STATUS.UPLOADED_OK
                ? "text-success"
                : "text-warning"
            }`}
          >
            {service.uploadStatus === UPLOAD_STATUS.UPLOADED_OK &&
              service.strings.uploadedOk}
            {service.uploadStatus === UPLOAD_STATUS.UPLOADED_ERROR &&
              service.strings.uploadedError}
          </span>
        </p>
      </div>
    </div>
  );

  return (
    <AuthLayout>
      <ModalAddUsersGroupPrompt
        result={service.uploadedResult}
        onClose={service.onCloseModal}
      />
      <div className="p-3">
        <div className="flex flex-row justify-start items-center gap-2 h-12 mb-2">
          <Link to={`/users`}>
            <Svg
              SvgPath={<SvgPath.SvgChevronDown />}
              width="24"
              height="24"
              className="icon -rotate-90 hover:fill-primary"
            />
          </Link>
          <h1 className="font-bold">{service.strings._title}</h1>
        </div>
        <div className="bg-white rounded section-body p-4">
          {service.uploadStatus === UPLOAD_STATUS.NOT_UPLOADED &&
            renderNotUploaded()}
          {service.uploadStatus === UPLOAD_STATUS.UPLOADING &&
            renderUploading()}
          {(service.uploadStatus === UPLOAD_STATUS.UPLOADED_OK ||
            service.uploadStatus === UPLOAD_STATUS.UPLOADED_ERROR) &&
            renderUploaded()}
          <p className="text-xs text-subline leading-6 mt-4">
            {service.strings.text1}
          </p>
          <p className="text-xs text-subline leading-6">
            {service.strings.text2}
          </p>
        </div>
      </div>
    </AuthLayout>
  );
};

export default AddUsersGroup;
