import loginAdminSchema from "./loginAdminSchema";

export { loginAdminSchema };
