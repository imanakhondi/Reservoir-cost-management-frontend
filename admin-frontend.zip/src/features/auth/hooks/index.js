import useLoginPageService from "./useLoginPageService";

export { useLoginPageService };
