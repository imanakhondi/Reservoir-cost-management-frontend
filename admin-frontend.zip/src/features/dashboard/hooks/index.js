import useDashboardPageService from "./useDashboardPageService";

export { useDashboardPageService };
