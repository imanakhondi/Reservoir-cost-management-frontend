const ENV = {
  appEnv: "production",
  name: "hamsaa_admin_panel",
  baseUrl: "http://127.0.0.1:3000",
  apiEndpoint: "http://127.0.0.1:8000/api/admin_panel",
};

export default ENV;
