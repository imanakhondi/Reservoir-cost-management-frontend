import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { slideDown, slideUp } from "es6-slide-up-down";
import { easeOutQuint } from "es6-easings";

import {
  ModalFilter,
  InputDatePicker,
  InputReactSelect,
  InputSelect,
  InputText,
} from "..";
import utils from "../../utils";
import Svg, { SvgPath } from "../svg";
import { genders, userStatuses } from "../../types/options";

const ModalUsersFilter = ({ provinces, cities, skills, onSubmit }) => {
  const pageState = useSelector((state) => state.pageReducer);
  const [expanded, setExpanded] = useState(true);
  const { modalUsersFilter: strings } = utils.getLSLocale();

  useEffect(() => {
    toggleDropdown();
  }, [expanded]);

  const toggleDropdown = () => {
    const element = document.querySelector("#more-filters");

    if (expanded) {
      slideUp(element);

      return;
    }

    slideDown(element, {
      duration: 400,
      easing: easeOutQuint,
    });
  };

  const onReset = () => {
    pageState?.useForm?.reset();
    onSubmit();
  };

  return (
    <ModalFilter strings={strings} onSubmit={onSubmit} onReset={onReset}>
      <div className="px-4 pb-px">
        <InputText field="filterName" />
        <InputText field="filterUsername" />
        <InputText field="filterMobile" />
        <InputSelect field="filterStatus" options={userStatuses} />
        <InputDatePicker field="filterCreatedAt" />
      </div>
      <div className="border border-table-border h-px my-4 flex flex-row justify-center gap-2 relative">
        <div
          className="absolute -top-2 px-4 bg-white flex flex-row items-center gap-2 cursor-pointer"
          onClick={() => setExpanded((expanded) => !expanded)}
        >
          {expanded && (
            <Svg
              SvgPath={<SvgPath.SvgPlus pathClassName={"stroke-primary"} />}
              width="12"
              height="12"
              className="icon-complex"
              viewBox={"0 0 12 12"}
            />
          )}
          {!expanded && (
            <Svg
              SvgPath={<SvgPath.SvgMinus pathClassName={"stroke-primary"} />}
              width="12"
              height="2"
              className="icon-complex"
              viewBox={"0 0 12 2"}
            />
          )}
          <span className="text-primary text-xs">{strings.moreFilters}</span>
        </div>
      </div>
      <div id="more-filters" className="p-4 pt-0 hidden">
        <InputDatePicker field="filterBirthDate" containerClassName="" />
        <InputSelect field="filterGender" options={genders} />
        <InputSelect field="filterJobTitle" />
        <InputSelect field="filterProvince" options={provinces} />
        <InputSelect field="filterCity" options={cities} />
        <InputReactSelect field="filterSkills" options={skills} />
      </div>
    </ModalFilter>
  );
};

export default ModalUsersFilter;
