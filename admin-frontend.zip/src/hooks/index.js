import usePage from "./usePage";
import usePost from "./usePost";

export { usePage, usePost };
