import React from "react";
import { useSelector } from "react-redux";
import {
  Navigate,
  Route,
  BrowserRouter as Router,
  Routes,
} from "react-router-dom";

import { PAGE_COMPONENTS } from "../../types";

const renderNotAuthenticatedRoutes = () => (
  <>
    <Route path={`/errors/404`} element={<PAGE_COMPONENTS.Error404 />} />
    <Route path={`/admins/login`} element={<PAGE_COMPONENTS.Login />} />
    <Route path="*" element={<Navigate to={`/errors/404`} />} />
  </>
);

const renderAuthenticatedRoutes = () => (
  <>
    <Route path={`/errors/404`} element={<PAGE_COMPONENTS.Error404 />} />
    <Route path={`/users/add`} element={<PAGE_COMPONENTS.AddUser />} />
    <Route
      path={`/users/add_group`}
      element={<PAGE_COMPONENTS.AddUsersGroup />}
    />
    <Route path={`/users`} element={<PAGE_COMPONENTS.Users />} />
    <Route path={`/`} element={<PAGE_COMPONENTS.Dashboard />} />
    <Route path="*" element={<Navigate to={`/errors/404`} />} />
  </>
);

const AppRoutes = () => {
  const adminState = useSelector((state) => state.adminReducer);

  return (
    <Router>
      <Routes>
        {!adminState?.admin && renderNotAuthenticatedRoutes()}
        {adminState?.admin && renderAuthenticatedRoutes()}
      </Routes>
    </Router>
  );
};

export default AppRoutes;
